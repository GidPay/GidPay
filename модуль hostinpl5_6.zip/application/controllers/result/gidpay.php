﻿<?php
/*
Copyright (c) 2023-2024 GidPay.ru
*/
class gidpayController extends Controller {
	public function index() {
		$this->load->model('users');
		$this->load->model('invoices');
		
		if($this->request->server['REQUEST_METHOD'] == 'POST') {
			$errorPOST = $this->validatePOST();
			if(!$errorPOST) {
				$amount = $this->request->post['amount'];
				$invid = $this->request->post['order_id'];
				
				$invoice = $this->invoicesModel->getInvoiceById($invid);
				
				$this->usersModel->upUserBalance($invoice['user_id'], $amount);
				
				$this->invoicesModel->updateInvoice($invid, array('invoice_status' => 1));
				return "OK$invid\n";
			} else {
				return "$errorPOST";
			}
		} else {
			return "Invalid request!";
		}
	}
	
	private function validatePOST() {
		$result = null;
		
		$amount = $this->request->post['amount'];
		$invid = $this->request->post['order_id'];
		$signature = $this->request->post['sign'];
		
		$password = $this->config->gidpay_secretkey;
		$login = $this->config->gidpay_id;
	
		if(!$this->invoicesModel->getTotalInvoices(array('invoice_id' => (int)$invid))) {
			$result = "Invalid invoice!";
		}
        elseif(strtoupper($signature) != strtoupper(hash('sha256', "$login:$amount:$password:$invid"))) {
			$result = "Invalid signature!";
		}
		return $result;
	}
}
?>
